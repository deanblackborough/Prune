#pragma once

#include "prune/core/defaults.hpp"
#include "prune/scene/game_object.hpp"
#include "prune/scene/game_object_manager.hpp"
#include "prune/scene/scene_camera.hpp"

namespace prune {

    struct SceneViewport {
        int screen_x = 0;
        int screen_y = 0;
        int width = 0;
        int height = 0;
        bool hovered = false;
        bool focused = false;

        [[nodiscard]] bool has_area() const noexcept {
            return width > 0 && height > 0;
        }

        [[nodiscard]] bool contains(int x, int y) const noexcept {
            return x >= screen_x &&
                y >= screen_y &&
                x < (screen_x + width) &&
                y < (screen_y + height);
        }
    };

    struct SceneOptions {
        bool highlight_selected = true;
    };

    struct GridOptions {
        bool show_grid = true;
        bool snap_to_grid = true;
        int grid_size = k_default_object_size;
        int nudge_step = 8;
        int shift_nudge_steps = 4;

        int min_grid_size = k_min_object_size;
        int max_grid_size = k_max_object_size;
        int min_nudge_step = 4;
        int max_nudge_step = 64;
    };

    struct DragState {
        bool active = false;
        GameObjectId object_id = k_invalid_game_object_id;
        Transform object_start{};
        Transform mouse_start_world{};
    };

    struct SceneState {
        SceneViewport viewport{};
        GridOptions grid_options{};
        DragState drag_state{};
        SceneCamera camera{};

        SceneOptions scene_options{};

        GameObjectManager objects;
    };

}
